package home.project.tomaber.MeCCG;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeCcgApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeCcgApplication.class, args);
	}

}
