package home.project.tomaber.MeCCG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeCcgApplicationTests {

	@Test
	void contextLoads() {
	}

}
